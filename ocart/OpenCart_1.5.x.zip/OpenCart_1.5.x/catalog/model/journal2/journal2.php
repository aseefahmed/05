<?php
define('JOURNAL_IS_CATALOG', true);